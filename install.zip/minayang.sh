wget https://tmtunnel.me/minacantik/install.zip
wget https://tmtunnel.me/minacantik/instalupdate.sh
chmod 755 instalupdate.sh
./instalupdate.sh
rm install.zip
rm installupdate.sh
