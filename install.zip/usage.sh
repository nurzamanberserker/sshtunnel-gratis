#!/bin/bash
cat /etc/xray/config.json | grep '^#' | cut -d ' ' -f 2 | sort | uniq > .xrayuser
data=$(cat .xrayuser | sed 's/#[^ ]*//g')
today=$(date +%Y-%m-%d)
DB="/var/lib/minacantik/pemakaian.db"
json_array='[]'
for USER in $data 
do
# cek protocol
protocol=$(sqlite3 "$DB" "SELECT protocol FROM user WHERE username = '$USER';")
cari=">>>$USER>>>"
if xray api statsquery --server=127.0.0.1:10085 | grep -q "$cari"; then
    xray api stats --name="user>>>$USER>>>traffic>>>downlink" --server=127.0.0.1:10085 > .makan1
    JSON=$(cat .makan1)
    # Mendekode JSON menggunakan jq dan mengambil nilai dari kunci "value"
    VALUE=$(echo $JSON | jq -r '.stat.value')
    xray api stats --name="user>>>$USER>>>traffic>>>uplink" --server=127.0.0.1:10085 > .makan2
    JSON1=$(cat .makan2)
    # Mendekode JSON menggunakan jq dan mengambil nilai dari kunci "value"
    VALUE1=$(echo $JSON1 | jq -r '.stat.value')  
    
    #Value total
    total=$(($VALUE+$VALUE1))
    else
    total="0"
  fi
  SUM_DAY=$(sqlite3 "$DB" "SELECT COALESCE(SUM(use), 0) FROM jam WHERE username = '$USER' AND date = '$today';")
  SUM_DAY2=$(sqlite3 "$DB" "SELECT COALESCE(SUM(use), 0) FROM hari WHERE username = '$USER'")
    limitbw=$(sqlite3 $DB "SELECT COALESCE(bw, 0) FROM user WHERE username = '$USER'")
    limitip=$(sqlite3 "$DB" "SELECT COALESCE(ip, 2) FROM user WHERE username = '$USER'")
    sum=$(($SUM_DAY+$total))
    sumall=$(($SUM_DAY2+$sum))
# Create a JSON object for this iteration
  json_object=$(jq -n \
                    --arg user "$USER" \
                    --argjson limitbw "$limitbw" \
                    --argjson limitip "$limitip" \
                    --argjson sum "$sum" \
                    --argjson sumall "$sumall" \
                    '{user: $user, limitbw: $limitbw, limitip: $limitip, sum: $sum, sumall: $sumall}')

  # Add the JSON object to the array
  json_array=$(echo $json_array | jq --argjson new_item "$json_object" '. += [$new_item]')
done
# echo $json_array | jq '.'
echo $json_array > /var/www/html/usage.json
